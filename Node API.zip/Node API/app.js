const express = require('express');
const mongoose = require('mongoose');

// Initialize Express
const app = express();
const port = 3000; // Define your desired port

// Connect to MongoDB
mongoose.connect('mongodb://localhost/bookstore', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to the database');
});

// Define the book schema
const bookSchema = new mongoose.Schema({
  title: String,
  author: String,
  summary: String,
});

const Book = mongoose.model('Book', bookSchema);

// Middleware to parse JSON
app.use(express.json());

// Routes for CRUD operations
app.post('/books', async (req, res) => {
  const { title, author, summary } = req.body;
  const book = new Book({ title, author, summary });
  await book.save();
  res.json(book);
});

app.get('/books', async (req, res) => {
  const books = await Book.find();
  res.json(books);
});

app.get('/books/:id', async (req, res) => {
  const book = await Book.findById(req.params.id);
  res.json(book);
});

app.put('/books/:id', async (req, res) => {
  const { title, author, summary } = req.body;
  const updatedBook = await Book.findByIdAndUpdate(
    req.params.id,
    { title, author, summary },
    { new: true }
  );
  res.json(updatedBook);
});

app.delete('/books/:id', async (req, res) => {
  await Book.findByIdAndRemove(req.params.id);
  res.json({ message: 'Book deleted' });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
